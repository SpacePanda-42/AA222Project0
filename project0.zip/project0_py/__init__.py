#
# File: __init__.py
#

from .project0 import f